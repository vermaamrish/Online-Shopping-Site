
<html>
    <head>
        <title>Summer Training Project</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
       <link rel="stylesheet" type="text/css" href="style/main.css">
        <link rel="stylesheet" type="text/css" href="style/navistyle.css">
        <link rel="stylesheet" type="text/css" href="style/login.css">


 </head>
    <body>
        <?php
        include 'contactinfo.php';
        ?>
        <div id="div1"></div>
        <div id="div2">
            <div class="header">
                <a href="#"><img style="float:left" src="images/high-quality-paper-color-f.jpg" width="150px" height="130px"></a>
                <div class="headname">
                    <div >
                        <h1 style="float:left;text-shadow:2px 2px 2px gray; "><font size="40px"><b>FASHION WORLD</b></font></h1>
                     </div>
                    <?php
                    include 'social.php';
                    ?>


                </div>
            </div>
            <br clear="all">
      <!--      <div style="margin-top:-25px;">
               <ul class="block-menu">
             <li ><a href="/" class="three-d" >Home
                	<span aria-hidden="true" class="three-d-box">
                        <span class="front">Home</span>
                        <span class="back">Home</span>
                    </span>
               </a>
             </li>
             <li><a href="/demos" class="three-d">ABOUT US
                    <span aria-hidden="true" class="three-d-box">
                       <span class="front">ABOUT US</span>
                       <span class="back">ABOUT US</span>
                    </span>
                 </a>
            </li>
                   <li><a href="/demos" class="three-d">MENS SECTION
                    <span aria-hidden="true" class="three-d-box">
                       <span class="front">MENS SECTION</span>
                       <span class="back">MENS SECTION</span>
                    </span>
                 </a>
            </li>
                   <li><a href="/demos" class="three-d">WOMENS SECTION
                    <span aria-hidden="true" class="three-d-box">
                       <span class="front">WOMENS SECTION</span>
                       <span class="back">WOMENS SECTION</span>
                    </span>
                 </a>
            </li>
                   <li><a href="/demos" class="three-d">KIDS SECTION
                    <span aria-hidden="true" class="three-d-box">
                       <span class="front">KIDS SECTION</span>
                       <span class="back">KIDS SECTION</span>
                    </span>
                 </a>
            </li>

                   <li><a href="/demos" class="three-d">NEW ARRIVALS
                    <span aria-hidden="true" class="three-d-box">
                       <span class="front">NEW ARRIVALS</span>
                       <span class="back">NEW ARRIVALS</span>
                    </span>
                 </a>
            </li>
                   <li><a href="/demos" class="three-d">CONTACT US
                    <span aria-hidden="true" class="three-d-box">
                       <span class="front">CONTACT US</span>
                       <span class="back">CONTACT US</span>
                    </span>
                 </a>
            </li>
                    <li><a href="/demos" class="three-d">OFFERS
                    <span aria-hidden="true" class="three-d-box">
                       <span class="front">OFFERS</span>
                       <span class="back">OFFERS</span>
                    </span>
                 </a>
            </li>


</ul>

            </div>-->
            <?php
              include 'menubar.php';
            ?>
            <br><br>

            <div class="menus">
                 <div class="search">
                <center>
                    <form>
                        <div style="display:inline;list-style:none;margin-left:none;">
                        <ul style="list-style:none;">
                          <li><input type="text" name="search" style="width:130px;float:left;margin-left:-10px;" value="Search" ><img src="images/searchbutton.PNG"></li>
                           <li></li>

                            </ul>
                        </div>

                    </form>
                </center>
            </div><hr>
           <div class="anim">
                <h3 style="margin-left:20px;font-family: 'Passion One', Arial, sans-serif;" ><b><u>Men's Fashion</u></b></h3>
                <ul type="bullet" class="list">
                    <li><a href="mens%20section.php" target="_self">Men's Shirts</a><br></li>
                    <li><a href="#">Men's Jeans</a><br></li>
                    <li><a href="#">Men's Footwear</a><br></li>
                    <li><a href="#">Men's watches </a><br></li>
                </ul><hr>

                <h3 style="margin-left:20px;font-family: 'Passion One', Arial, sans-serif;"><b><u>Women's Fashion</u></b></h3>
                <ul type="bullet" class="list" >
                    <li><a href="womens%20section.php" target="_self">Women's Tops</a><br></li>
                    <li><a href="#">Women's Jeans</a><br></li>
                    <li><a href="#">Women's Footwear</a><br></li>
                    <li><a href="#">Women's watches </a><br></li>
                </ul><hr>
                <h3 style="margin-left:20px;font-family: 'Passion One', Arial, sans-serif;"><b><u>Kid's Fashion</u></b></h3>
                <ul type="bullet" class="list">
                    <li><a href="#">Kid's Shirts</a><br></li>
                    <li><a href="#">Kid's Jeans</a><br></li>
                    <li><a href="#">Kid's Footwear</a><br></li>
                    <li><a href="#">Kid's watches </a><br></li>
                </ul>
                     </div>
            </div>
         <div style="width:5px;height:255.5px;float:left">
         </div>
         <center>
             <div style="height:380px;width:380px;border:5px double;background:#94E4E8">
           <div class="signupform">

    <form method="post">
        <h2>New User Sign Up</h2>
        <table>
            <tr>
                <td align="center" width="150px"><b>Username:</b></td>
                <td><input type="text" name="name"/><br><br></td>
            </tr>
             <tr>
                 <td align="center" width="150px"><b> Email:</b></td>
                <td><input type="text" name="pass"/><br><br></td>
            </tr>
            <tr>
                <td align="center" width="150px"><b>Password:</b></td>
                <td><input type="password" name="name"/><br><br></td>
            </tr>
             <tr>
                 <td align="center" width="150px"><b> Contact No:</b></td>
                <td><input type="text" name="pass"/><br><br></td>
            </tr>

        </table><br>
                      <center><input style="margin-left:140px;"type="submit" name="login" value="Sign Up"/></center>


    </form>

    </center>

            </div>
    </div>
            <br>

        <div id="div3"></div>



    </body>
</html>