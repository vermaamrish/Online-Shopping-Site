<div class="footer" style="background:#5eebfd;height:100px;width:600px;margin-top:-20px;"> 
<div id="foot" style="display:inline;float:right;margin-right:-210px;">
                    <ul style="list-style:none;background:#a4e626;">
              <li><a href="https://www.facebook.com/" target="_blank"><img src="images/beer_cap_facebook.png" height="40px" width="40px" ></a></li>
       <li><a href="https://twitter.com/login" target="_blank"><img src="images/beer_cap_twitter.png"  height="40px" width="40px"></a></li>
       <li><a href="https://www.linkedin.com/uas/login" target="_blank"><img src="images/beer_cap_linkedin.png"  height="40px" width="40px"></a></li> 
             <li></li>
       
                        </ul>  </div>
</div>