
<html>
<head>
<style>
.dropbtn {
    background-color: black;
    color: white;
    padding: 12px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #1c84d1;
}
</style>
</head>
<body>

<div style="position:absolute;z-index:100;margin-top:-10px;">
<div class="dropdown">
    <a href="index.php" target="_self" style="margin:0px;"><button class="dropbtn">HOME&nbsp;</button></a>
    <div class="dropdown-content">
  </div>
</div>
<div class="dropdown" >
<button class="dropbtn">ABOUT US</button>
  </div>
    <div class="dropdown" >
  <button class="dropbtn">MEN'S FASHION&nbsp;</button>
  <div class="dropdown-content">
    <a href="mens%20shirts.php" target="_self">T-Shirt's</a>
    <a href="mens%20shirts.php" target="_self">Shirt's</a>
    <a href="mens%20jeans.php" target="_self">Jeans</a>
    <a href="mens%20jeans.php" target="_self">Trousers</a>
    <a href="mens%20footwear.php" target="_self">Footwear</a>
    <a href="mens%20watches.php" target="_self">Watches</a>
  </div>
</div>
<div class="dropdown" >
<button class="dropbtn">WOMEN'S FASHION&nbsp;</button>
  <div class="dropdown-content">
    <a href="womensTops.php" target="_self">Tops</a>
    <a href="WomensJeans.php" target="_self">Jeans</a>
    <a href="WomenFootwear.php" target="_self">Footwear</a>
    <a href="WomenWatches.php" target="_self">Watches</a>
  </div>
</div>
    <div class="dropdown" >
  <button class="dropbtn">KID'S FASHION&nbsp;</button>
  <div class="dropdown-content">
    <a href="KidShirts.php" target="_self">Shirts</a>
    <a href="KidJeans.php" target="_self">Jeans</a>
    <a href="KidFootwear.php" target="_self">Footwear</a>
    <a href="KidWatches.php" target="_self">Watches</a>
  </div>
</div>
<div class="dropdown" >
    <a href="index.php" target="_self"><button class="dropbtn" >NEW ARRIVALS</button></a>
  <div class="dropdown-content">
   
  </div>
</div>
    <div class="dropdown">
        <a href="ContactUs.php" target="_self"><button class="dropbtn" >CANTACT US</button></a>
  <div class="dropdown-content">
   
  </div>
</div>
<div class="dropdown" >
<button class="dropbtn">OFFERS</button>
  <div class="dropdown-content">
   
  </div>
</div>
    </div>
</body>
</html>
