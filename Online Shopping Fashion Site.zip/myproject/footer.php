<div class="footer" style="margin-top:10em;background:#5eebfd;">
    <br>
    <div id="foot">
   <ul>
       <li><a href="#"><strong><font size="3px">Home</font></strong></a></li>
       <li><a href="#"><strong><font size="3px">About Us</font></strong></a></li>
       <li><a href="#"><strong><font size="3px">Men's Fashion</font></strong></a></li>
       <li><a href="#"><strong><font size="3px">Women's Fashion</font></strong></a></li>
       <li><a href="#"><strong><font size="3px">Kid's Fashion</font></strong></a></li>
       <li><a href="#"><strong><font size="3px">New Arrivals</font></strong></a></li>
       <li><a href="#"><strong><font size="3px">Offers</font></strong></a></li> 
       
    </ul><br><br><br>
        <center><strong><font size="5px">copyright@verma.amrish159@2016</font></strong></center>
        
       
    </div>
</div>