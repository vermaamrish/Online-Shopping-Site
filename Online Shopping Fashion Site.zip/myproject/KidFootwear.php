
<html>
    <head>
        <title>Summer Training Project</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
       <link rel="stylesheet" type="text/css" href="style/main.css">
        <link rel="stylesheet" type="text/css" href="style/navistyle.css">
        <link rel="stylesheet" type="text/css" href="style/login.css">
        
        
 </head>   
    <body>
        <?php
        include 'contactinfo.php';
        ?>
        <div id="div1"></div>
        <div id="div2">
            <div class="header">
                <a href="#"><img style="float:left" src="images/high-quality-paper-color-f.jpg" width="150px" height="130px"></a> 
                <div class="headname">
                    <div >
                        <h1 style="float:left;text-shadow:2px 2px 2px gray; "><font size="40px"><b>FASHION WORLD</b></font></h1>
                     </div>
                    <?php
                    include 'social.php';
                    ?>
                    
                    
                </div>
            </div>
            <br clear="all">
      <!--      <div style="margin-top:-25px;">
               <ul class="block-menu">
	         <li ><a href="/" class="three-d" >Home
	            	<span aria-hidden="true" class="three-d-box">
                        <span class="front">Home</span>
                        <span class="back">Home</span>
		            </span>
	           </a>
             </li>
	         <li><a href="/demos" class="three-d">ABOUT US
		            <span aria-hidden="true" class="three-d-box">
			           <span class="front">ABOUT US</span>
			           <span class="back">ABOUT US</span>
		            </span>
	             </a>
            </li>
                   <li><a href="/demos" class="three-d">MENS SECTION
		            <span aria-hidden="true" class="three-d-box">
			           <span class="front">MENS SECTION</span>
			           <span class="back">MENS SECTION</span>
		            </span>
	             </a>
            </li>
                   <li><a href="/demos" class="three-d">WOMENS SECTION
		            <span aria-hidden="true" class="three-d-box">
			           <span class="front">WOMENS SECTION</span>
			           <span class="back">WOMENS SECTION</span>
		            </span>
	             </a>
            </li>
                   <li><a href="/demos" class="three-d">KIDS SECTION
		            <span aria-hidden="true" class="three-d-box">
			           <span class="front">KIDS SECTION</span>
			           <span class="back">KIDS SECTION</span>
		            </span>
	             </a>
            </li>
                   
                   <li><a href="/demos" class="three-d">NEW ARRIVALS
		            <span aria-hidden="true" class="three-d-box">
			           <span class="front">NEW ARRIVALS</span>
			           <span class="back">NEW ARRIVALS</span>
		            </span>
	             </a>
            </li>
                   <li><a href="/demos" class="three-d">CONTACT US
		            <span aria-hidden="true" class="three-d-box">
			           <span class="front">CONTACT US</span>
			           <span class="back">CONTACT US</span>
		            </span>
	             </a>
            </li>
                    <li><a href="/demos" class="three-d">OFFERS
		            <span aria-hidden="true" class="three-d-box">
			           <span class="front">OFFERS</span>
			           <span class="back">OFFERS</span>
		            </span>
	             </a>
            </li>
                   
	
</ul>
                
            </div>-->
            <?php
              include 'menubar.php';
            ?>
            <br><br>
           
            <div class="menus">
                 <div class="search">
                <center>
                    <form>
                        <div style="display:inline;list-style:none;margin-left:none;">
                        <ul style="list-style:none;">
                          <li><input type="text" name="search" style="width:130px;float:left;margin-left:-10px;" value="Search" ><img src="images/searchbutton.PNG"></li>
                           <li></li>

                            </ul>
                        </div>
                               
                    </form>
                </center>
            </div><hr>
          <div class="anim">
                <h3 style="margin-left:20px;font-family: 'Passion One', Arial, sans-serif;" ><b><u>Men's Fashion</u></b></h3>
                <ul type="bullet" class="list">
                    <li><a href="mens%20shirts.php" target="_self">Men's Shirts</a><br></li>
                    <li><a href="mens%20jeans.php" target="_self">Men's Jeans</a><br></li>
                    <li><a href="mens%20footwear.php" target="_self">Men's Footwear</a><br></li>
                    <li><a href="mens%20watches.php" target="_self">Men's watches </a><br></li>
                </ul><hr>
                
                <h3 style="margin-left:20px;font-family: 'Passion One', Arial, sans-serif;"><b><u>Women's Fashion</u></b></h3>
                <ul type="bullet" class="list" >
                   <li><a href="womensTops.php" target="_self">Women's Tops</a><br></li>
                    <li><a href="WomensJeans.php" target="_self">Women's Jeans</a><br></li>
                    <li><a href="WomenFootwear.php" target="_self">Women's Footwear</a><br></li>
                    <li><a href="WomenWatches.php" target="_self">Women's watches </a><br></li>
                </ul><hr>
                <h3 style="margin-left:20px;font-family: 'Passion One', Arial, sans-serif;"><b><u>Kid's Fashion</u></b></h3>
                <ul type="bullet" class="list">
                   <li><a href="KidShirts.php" target="_self">Kid's Shirts</a><br></li>
                    <li><a href="KidJeans.php" target="_self">Kid's Jeans</a><br></li>
                    <li><a href="KidFootwear.php" target="_self">Kid's Footwear</a><br></li>
                    <li><a href="KidWatches.php" target="_self">Kid's watches </a><br></li>
                </ul>
                     </div>
            </div>
         <div style="width:5px;height:255.5px;float:left">
         </div>
            <div class="slider">
                    <img class="mySlides" src="images/1.jpg" style="width:100%">
                    <img class="mySlides" src="images/2.jpg" style="width:100%">
                    <img class="mySlides" src="images/3.jpg" style="width:100%">
                    <img class="mySlides" src="images/4.jpg" style="width:100%">
                    <img class="mySlides" src="images/5.jpg" style="width:100%">
                    <img class="mySlides" src="images/6.jpg" style="width:100%">
                <?php
                  include 'js/images.js';
                ?>
            </div>
             <div style="width:5px;height:255.5px;float:left">
         </div>
            <div class="loginform">
                 <center>
    <form method="post">
        <h2>LOGIN</h2>
        <table>
            <tr>
                <td align="center" width="100px"><b>Username:</b></td>  
                <td><input type="text" name="name"/><br><br></td>
            </tr>
             <tr>
                 <td align="center"><b> Password:</b></td>  
                <td><input type="password" name="pass"/><br><br></td>
            </tr>
        </table> <br> 
        <input type="submit" name="login" value="LOG IN"/>
        <a href="Signup.php" target="_self"><input type="submit" name="forgot" value="NEW USER?"/></a><br>
    </form>
        
    </center>
                
            </div>
            
            <div class="section group" style="margin-left:15.2em;margin-top:21em;position:absolute;padding:15px;">
                <center><Strong><font size="5px"><u>KIDS FOOTWEAR</u></font></Strong></center>
                <br>
	<div class="col span_1_of_4" >
        
	    <img src="images/Kids/footwear/kf1.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	    <img src="images/Kids/footwear/kf2.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	     <img src="images/Kids/footwear/kf3.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	   <img src="images/Kids/footwear/kf4.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
               
            </div>
            <br clear="all">
         <div class="section group" style="margin-left:15.2em;margin-top:-45em;position:absolute;padding:15px;">
	<div class="col span_1_of_4" >
        
	    <img src="images/Kids/footwear/kf5.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	    <img src="images/Kids/footwear/kf6.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	     <img src="images/Kids/footwear/kf7.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	   <img src="images/Kids/footwear/kf8.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
               
            </div> 
            <div class="section group" style="margin-left:15.2em;margin-top:-20em;position:absolute;padding:15px;">
	<div class="col span_1_of_4" >
        
	    <img src="images/Kids/footwear/kf9.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	    <img src="images/Kids/footwear/kf10.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	     <img src="images/Kids/footwear/kf11.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
	<div class="col span_1_of_4">
	   <img src="images/Kids/footwear/kf12.jpg">
        <center><p>Kid Casual Shoe</p></center>
	</div>
               
            </div> 
           
            
        <div id="div3"></div>
            <?php
            include'footer.php';
            ?>
              

    </body>
</html>