<div class="footer" style="background:#a4e626;height:10px;margin-top:-20px;">

    <div id="foot" style="display:inline;float:right;margin-right:0px;">
   <ul style="list-style:none;">
           <li><strong>Contact Us-</strong>+91-8800914542</li>
       <li></li>
       
    </ul>   
    </div>
</div>